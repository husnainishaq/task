// App.js

import React, { useEffect } from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';

import LoginForm from './page/Login';
import RegisterForm from './page/Register';
import Dashboard from './page/Dashboard';
import PrivateRoute from './components/privateRoute';
import Feedback from './page/Feedback';
import Allfeedback from './page/Allfeedback';



const App = () => {


  return (
    <Router>
      <Routes>
        <Route path="/login" element={<LoginForm />} />
        <Route path="/register" element={<RegisterForm />} />
        <Route exact path='/' element={<PrivateRoute />}>
          <Route exact path='/' element={<Dashboard />} />
          <Route exact path='/feedback' element={<Feedback />} />
          <Route exact path='/allfeedback' element={<Allfeedback />} />
        </Route>

      </Routes>
    </Router>
  );
};

export default App;
