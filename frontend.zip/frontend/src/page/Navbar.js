import React from 'react';
import styled from 'styled-components';
import { useNavigate } from 'react-router-dom';

import  '../css/Navbar.css';
const NavBarSide = () => {
    const history = useNavigate();
  const handleLogout = () => {
    localStorage.removeItem("token");
    localStorage.removeItem("loginTime");
    localStorage.removeItem("user");
  
    history("/login");
  };
   const loginToken = localStorage.getItem("token");
  return (
   <>
     <nav>
      <ul className="list">
      <a  className="logo">
 
         </a>
          
           
           {!loginToken ? 
           <>
          <li className="items"><a href="/Login">Login</a></li>
          <li className="items"><a href="/Register">Register</a></li></>
            :<>
            <li className="items"><a href="/allfeedback">All Feedback</a></li>
            <li className="items"><a href="/feedback">Add Feedback</a></li>
           <button onClick={handleLogout}>Log Out</button></>
        }
               </ul>
      
    </nav>
   
  
    </>
  );
};

export default NavBarSide;