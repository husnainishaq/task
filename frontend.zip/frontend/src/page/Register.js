import React, { useState,Component } from 'react';
import NavBarSide from './Navbar';
import '../css/Auth.css';
import { useNavigate } from 'react-router-dom';
 // Update the import path based on your file structure

const RegisterForm = () => {
  const history = useNavigate();// Use the useAuth hook to access the authentication context
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    password: '',
  });

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData((prevData) => ({
      ...prevData,
      [name]: value,
    }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    if (formData.email.trim() === '' || formData.password.trim() === '' || formData.name.trim() === '') {
      alert('Please fill in name email and password fields.');
      return;
    }

    try {
      const response = await fetch('http://127.0.0.1:8000/api/auth/register', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(formData),
      });

      if (!response.ok) {
        const errorData = await response.json();
        alert(`Error: ${errorData.message}`);
        return;
      }
      const responseData = await response.json();
      console.log(responseData , responseData.user , "responseData")
      localStorage.setItem("token" , responseData.token)
      const loginTime = new Date().toISOString(); // Current time in ISO format
    localStorage.setItem("loginTime", loginTime);
      history("/");
 
    } catch (error) {
      console.error('Error during login:', error);
      alert('An unexpected error occurred during login.');
    }
  };

  return (
<>
<NavBarSide />
 <div class="login-page">
  <div class="form">
    <h1>Add user</h1>
    <form class="login-form" onSubmit={handleSubmit}>
    <input type="name"
          name="name"
          value={formData.name}
          onChange={handleChange}
          required/>
      <input type="email"
          name="email"
          value={formData.email}
          onChange={handleChange}
          required/>
      <input type="password"
          name="password"
          value={formData.password}
          onChange={handleChange}
          required/>
      <button type="submit">login</button>
      <p class="message">Not registered? <a href="login">Create an account</a></p>
    </form>
  </div>
</div>
</>
  );
};

export default RegisterForm;
