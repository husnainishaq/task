import React, { useState, useEffect } from 'react';


import Feedback from './Feedback';


const Dashboard = () => {

  const [showRefreshButton, setShowRefreshButton] = useState(false);
  const loginToken = localStorage.getItem("token");
  const loginTime = localStorage.getItem("loginTime");



  


  return (
    <div>

 <Feedback />
    
      
    </div>
  );
};

export default Dashboard;
