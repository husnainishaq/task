import React, { useState } from 'react';
import axios from 'axios';
import { useNavigate } from 'react-router-dom';
import NavBarSide from './Navbar';
const Feedback = () => {
  const history = useNavigate();
  const userss = JSON.parse(localStorage.getItem('user'));
  const loginToken = localStorage.getItem('token');
  const userId = userss.id;

  const [formData, setFormData] = useState({
    title: '',
    description: '',
    category: 'bug report', // Set a default category
    user_id: userId,
  });

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData((prevData) => ({
      ...prevData,
      [name]: value,
    }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
console.log('sadf',loginToken)
    const headers = {
       'Authorization': `Bearer ${loginToken}`,
  'Content-Type': 'application/json',
    };
console.log('sadf',loginToken,headers)
    const config = {
      method: 'post',
      url: 'http://127.0.0.1:8000/api/add_feedback',
      headers: {
        ...headers,
        'Content-Type': 'application/json', // Specify the content type
      },
      data: formData,
    };

    try {
      const response = await axios.request(config);
      console.log(JSON.stringify(response.data));
      history("/allfeedback");
    } catch (error) {
      console.log(error);
    }
  };

  return (
    <>
    
    <NavBarSide />
    <div className="form">
      <h1>Add Feedback</h1>
      <form className="login-form" onSubmit={handleSubmit}>
        <input
          type="text"
          name="title"
          value={formData.title}
          onChange={handleChange}
          placeholder="Enter title"
          required
        />
        <input
          type="text"
          name="description"
          value={formData.description}
          onChange={handleChange}
          placeholder="Enter description"
          required
        />
        <select
          name="category"
          value={formData.category}
          onChange={handleChange}
        >
          <option value="bug report">Bug Report</option>
          <option value="feature request">Feature Request</option>
          <option value="improvement">Improvement</option>
        </select>

        <button type="submit">Submit</button>
        <p className="message">
          Not registered? <a href="login">Create an account</a>
        </p>
      </form>
    </div>
    </>
  );
};

export default Feedback;
