import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { useNavigate } from 'react-router-dom';
import NavBarSide from './Navbar';
import '../css/feed.css';
import Container from 'react-bootstrap/Container';
import Row from 'react-bootstrap/Row';
import Col from 'react-bootstrap/Col';

const Feedback = () => {
  const history = useNavigate();
  const userss = JSON.parse(localStorage.getItem('user'));
  const loginToken = localStorage.getItem('token');
  const userId = userss.id;
 const [allfeeds, setallfeeds] = useState([]);
 const [loading, setLoading] = useState(false);
 const [inputValue, setInputValue] = useState('');
  const [users, setUsers] = useState([]);

useEffect(() => {
    const fetchData = async () => {
      try {
        const response = await axios.get('http://127.0.0.1:8000/api/allFeedback', {
          headers: {
            'Authorization': `Bearer ${loginToken}`,
          },
        });
        setallfeeds(response.data);
        console.log(JSON.stringify(response.data));
      } catch (error) {
        console.error(error);
      }
    };

    fetchData(); // Call the function to fetch data when the component mounts or when the loginToken changes
  }, [loginToken]); 
useEffect(() => {
    const fetchUsers = async () => {
      try {
        setLoading(true);
        const response1 = await axios.get('http://127.0.0.1:8000/api/alluser', {
            headers: {
            'Authorization': `Bearer ${loginToken}`,
          },
          // Add any headers or parameters needed for your API request
        });
        console.log('response1',response1.data)
        setUsers(response1.data.users);
      } catch (error) {
        console.error('Error fetching users:', error);
      } finally {
        setLoading(false);
      }
    };

    // Fetch users only if the inputValue contains '@'
    if (inputValue.includes('@')) {
      fetchUsers();
    }
  }, [inputValue]);
 const handleInputChange = (e) => {
    setInputValue(e.target.value);
  };
      
  const filteredUsers = users.filter((user) =>
    user.name.includes(inputValue.substring(1)) // Exclude '@' from the comparison
  );

console.log(allfeeds.feedback,'dasd')

  return (
    <>
    <NavBarSide />
    <h1>ajsdlkj</h1>
   {loading ? (
        <p>Loading...</p>
      ) : (
        <div>
          <Container fluid>
      <Row>
          {Array.isArray(allfeeds.feedback) && allfeeds.feedback.length > 0 ? (
            allfeeds.feedback.map(feed => (
           
        <Col md={4}><div key={feed.id} className="feedback-box">
                <p>Name: {feed.name}</p>
                <p>Title: {feed.title}</p>
                <p>Description: {feed.description}</p>
              </div>
             <input
                  type="text"
                  placeholder="Type '@' to search users"
                  value={inputValue}
                  onChange={handleInputChange}
                />
              {loading && <p>Loading...</p>}

      {filteredUsers.length > 0 && (
        <ul>
          {filteredUsers.map((user) => (
            <li key={user.id}>{user.name}</li>
          ))}
        </ul>
      )}
              </Col>
       
                
            ))
            
          ) : (
            <p>No feedback available.</p>
          )}
           </Row>

    </Container>
        </div>
      )}

    </>
  );
};

export default Feedback;
