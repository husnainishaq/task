<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\User;
use App\Models\Feedbacks;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Validator;
use DB;

class FeedbackController extends Controller
{
    public function addFeedback(Request $request)
    {
     
            $validateUser = Validator::make($request->all(), 
            [
                'title' => 'required',
                'description' => 'required',
                'category' => 'required'
            ]);

            if($validateUser->fails()){
                return response()->json([
                    'status' => false,
                    'message' => 'validation error',
                    'errors' => $validateUser->errors()
                ], 401);
            }
        $user_id=auth()->user()->id;

            $feedback = Feedbacks::create([
                'title' => $request->title,
                'description' => $request->description,
                'category' => $request->category,
                'user_id' => $user_id,
            ]);


            return response()->json([
                'status' => true,
                'message' => 'feedback add In Successfully',
                'feedback' => $feedback
               
            ]);

       
    }

    public function allFeedback(Request $request)
    {
         User::where('email', $request->email)->first();
        $getfeedback =  DB::table('users')
->select('feedbacks.id','users.name','feedbacks.title','feedbacks.description','feedbacks.category')
->join('feedbacks','feedbacks.user_id','=','users.id')
->get();
         return response()->json([
                'status' => true,
                'message' => 'feedback get Successfully',
                'feedback' => $getfeedback
               
            ]);
    }
}
